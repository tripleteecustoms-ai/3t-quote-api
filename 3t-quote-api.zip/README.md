# 3T Quote API (Vercel)
Free serverless endpoints for 3T Print Solutions.

## Endpoints
- `/api/save-to-shopify-files` — saves uploaded files into **Shopify → Content → Files**
- `/api/quote-to-ac` — syncs form fields to **ActiveCampaign** (and triggers your automation)

## Environment Variables
In Vercel → Project → Settings → Environment Variables:

### Shopify
- `SHOPIFY_STORE=3tprintsolutions.myshopify.com`
- `SHOPIFY_ADMIN_TOKEN=shpat_...` (Custom app → Admin API access token)
- `SHOPIFY_API_VERSION=2024-07`

### ActiveCampaign
- `AC_API_URL=https://YOUR-ACCOUNT.api-us1.com`
- `AC_API_KEY=***`
- `AC_LIST_ID=###` (optional)
- `AC_AUTOMATION_ID=###` (recommended)
- `AC_TAG_ID=###` (optional)

## CORS
Both endpoints are pre-configured to accept requests from:
```
https://3tprintsolutions.com
```

## Use in your calculator
- Form action:
```
https://YOUR-PROJECT.vercel.app/api/save-to-shopify-files
```
- ActiveCampaign fetch:
```
https://YOUR-PROJECT.vercel.app/api/quote-to-ac
```

Deployed: 2025-08-14
